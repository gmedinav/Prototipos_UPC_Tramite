<?php

class NotificationsAppController extends AppController {
    
}

