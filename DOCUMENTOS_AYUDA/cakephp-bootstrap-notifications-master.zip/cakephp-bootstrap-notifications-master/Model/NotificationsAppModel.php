<?php

class NotificationsAppModel extends AppModel {

}

